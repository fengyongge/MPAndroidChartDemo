package com.zzti.fengyongge.mpandroidchart.bean;

/**
 * @author fengyongge
 * @des
 * @date 2017/4/28 0028
 */

public class LineChartBean {

    private String xString;
    private String yString;

    public String getxString() {
        return xString;
    }

    public void setxString(String xString) {
        this.xString = xString;
    }

    public String getyString() {
        return yString;
    }

    public void setyString(String yString) {
        this.yString = yString;
    }
}
